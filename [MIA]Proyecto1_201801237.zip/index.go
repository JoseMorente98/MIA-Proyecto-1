package main

import (
	InterpreteControlador "./Controlador/InterpreteControlador"
)

func main() {

	InterpreteControlador.Interprete()
}